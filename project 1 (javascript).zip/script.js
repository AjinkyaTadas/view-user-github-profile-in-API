fetch("https://api.github.com/users")
    .then((res) => res.json())
    .then((data) => {
        console.log(data[0].html_url);

        document.getElementById("profile-image").setAttribute("src", data[0].avatar_url);
        
        document.getElementById("username").innerText = data[0].login;

        document.getElementById("view-profile").setAttribute("href", data[0].html_url);




        document.getElementById("profile-image1").setAttribute("src", data[1].avatar_url);
        
        document.getElementById("username1").innerText = data[1].login;

        document.getElementById("view-profile1").setAttribute("href", data[1].html_url);




        document.getElementById("profile-image2").setAttribute("src", data[2].avatar_url);
        
        document.getElementById("username2").innerText = data[2].login;

        document.getElementById("view-profile2").setAttribute("href", data[2].html_url);




        document.getElementById("profile-image3").setAttribute("src", data[3].avatar_url);
        
        document.getElementById("username3").innerText = data[3].login;

        document.getElementById("view-profile3").setAttribute("href", data[3].html_url);




        document.getElementById("profile-image4").setAttribute("src", data[4].avatar_url);
        
        document.getElementById("username4").innerText = data[4].login;

        document.getElementById("view-profile4").setAttribute("href", data[4].html_url);
















        document.getElementById("profile-image5").setAttribute("src", data[5].avatar_url);
        
        document.getElementById("username5").innerText = data[5].login;

        document.getElementById("view-profile5").setAttribute("href", data[5].html_url);




        document.getElementById("profile-image6").setAttribute("src", data[6].avatar_url);
        
        document.getElementById("username6").innerText = data[6].login;

        document.getElementById("view-profile6").setAttribute("href", data[6].html_url);




        document.getElementById("profile-image7").setAttribute("src", data[7].avatar_url);
        
        document.getElementById("username7").innerText = data[7].login;

        document.getElementById("view-profile7").setAttribute("href", data[7].html_url);




        document.getElementById("profile-image8").setAttribute("src", data[8].avatar_url);
        
        document.getElementById("username8").innerText = data[8].login;

        document.getElementById("view-profile8").setAttribute("href", data[8].html_url);




        document.getElementById("profile-image9").setAttribute("src", data[9].avatar_url);
        
        document.getElementById("username9").innerText = data[9].login;

        document.getElementById("view-profile9").setAttribute("href", data[9].html_url);










    document.getElementById("profile-image10").setAttribute("src", data[10].avatar_url);
        
        document.getElementById("username10").innerText = data[10].login;

        document.getElementById("view-profile10").setAttribute("href", data[10].html_url);




        document.getElementById("profile-image11").setAttribute("src", data[11].avatar_url);
        
        document.getElementById("username11").innerText = data[11].login;

        document.getElementById("view-profile11").setAttribute("href", data[11].html_url);




        document.getElementById("profile-image12").setAttribute("src", data[12].avatar_url);
        
        document.getElementById("username12").innerText = data[12].login;

        document.getElementById("view-profile12").setAttribute("href", data[12].html_url);




        document.getElementById("profile-image13").setAttribute("src", data[13].avatar_url);
        
        document.getElementById("username13").innerText = data[13].login;

        document.getElementById("view-profile13").setAttribute("href", data[13].html_url);




        document.getElementById("profile-image14").setAttribute("src", data[14].avatar_url);
        
        document.getElementById("username14").innerText = data[14].login;

        document.getElementById("view-profile14").setAttribute("href", data[14].html_url);
















        document.getElementById("profile-image15").setAttribute("src", data[15].avatar_url);
        
        document.getElementById("username15").innerText = data[15].login;

        document.getElementById("view-profile15").setAttribute("href", data[15].html_url);




        document.getElementById("profile-image16").setAttribute("src", data[16].avatar_url);
        
        document.getElementById("username16").innerText = data[16].login;

        document.getElementById("view-profile16").setAttribute("href", data[16].html_url);




        document.getElementById("profile-image17").setAttribute("src", data[17].avatar_url);
        
        document.getElementById("username17").innerText = data[17].login;

        document.getElementById("view-profile17").setAttribute("href", data[17].html_url);




        document.getElementById("profile-image18").setAttribute("src", data[18].avatar_url);
        
        document.getElementById("username18").innerText = data[18].login;

        document.getElementById("view-profile18").setAttribute("href", data[18].html_url);




        document.getElementById("profile-image19").setAttribute("src", data[19].avatar_url);
        
        document.getElementById("username19").innerText = data[19].login;

        document.getElementById("view-profile19").setAttribute("href", data[19].html_url);











        document.getElementById("profile-image20").setAttribute("src", data[20].avatar_url);
        
        document.getElementById("username20").innerText = data[20].login;

        document.getElementById("view-profile20").setAttribute("href", data[20].html_url);




        document.getElementById("profile-image21").setAttribute("src", data[21].avatar_url);
        
        document.getElementById("username21").innerText = data[21].login;

        document.getElementById("view-profile21").setAttribute("href", data[21].html_url);




        document.getElementById("profile-image22").setAttribute("src", data[22].avatar_url);
        
        document.getElementById("username22").innerText = data[22].login;

        document.getElementById("view-profile22").setAttribute("href", data[22].html_url);




        document.getElementById("profile-image23").setAttribute("src", data[23].avatar_url);
        
        document.getElementById("username23").innerText = data[23].login;

        document.getElementById("view-profile23").setAttribute("href", data[23].html_url);




        document.getElementById("profile-image24").setAttribute("src", data[24].avatar_url);
        
        document.getElementById("username24").innerText = data[24].login;

        document.getElementById("view-profile24").setAttribute("href", data[24].html_url);
















        document.getElementById("profile-image25").setAttribute("src", data[25].avatar_url);
        
        document.getElementById("username25").innerText = data[25].login;

        document.getElementById("view-profile25").setAttribute("href", data[25].html_url);




        document.getElementById("profile-image26").setAttribute("src", data[26].avatar_url);
        
        document.getElementById("username26").innerText = data[26].login;

        document.getElementById("view-profile26").setAttribute("href", data[26].html_url);




        document.getElementById("profile-image27").setAttribute("src", data[27].avatar_url);
        
        document.getElementById("username27").innerText = data[27].login;

        document.getElementById("view-profile27").setAttribute("href", data[27].html_url);




        document.getElementById("profile-image28").setAttribute("src", data[28].avatar_url);
        
        document.getElementById("username28").innerText = data[28].login;

        document.getElementById("view-profile28").setAttribute("href", data[28].html_url);




        document.getElementById("profile-image29").setAttribute("src", data[29].avatar_url);
        
        document.getElementById("username29").innerText = data[9].login;

        document.getElementById("view-profile29").setAttribute("href", data[29].html_url);





     });


 
